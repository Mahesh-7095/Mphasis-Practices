

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
//@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String username=request.getParameter("username");
		out.print("Welcome "+username);
		HttpSession session = request.getSession();
		session.setAttribute("uname", username);
		
		ServletContext ctx = getServletContext();
		int totalUsers=(Integer)ctx.getAttribute("totalUsers");
		int currentUsers=(Integer)ctx.getAttribute("currentUsers");
		out.print("<br>total users = "+totalUsers);
		out.print("<br>current users = "+currentUsers);
		out.print("<br><a href='LogoutSevlet'>Logout</a>");
		out.close();
		
	}

}
