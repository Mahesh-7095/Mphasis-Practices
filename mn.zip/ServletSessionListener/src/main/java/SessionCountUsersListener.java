

import javax.servlet.ServletContext;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * Application Lifecycle Listener implementation class SessionCountUsersListener
 *
 */
@WebListener
public class SessionCountUsersListener implements HttpSessionListener {
	ServletContext ctx=null;
	static int totalUsers=0,currentUsers=0;

    /**
     * Default constructor. 
     */
    public SessionCountUsersListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see HttpSessionListener#sessionCreated(HttpSessionEvent)
     */
    public void sessionCreated(HttpSessionEvent event)  { 
         // TODO Auto-generated method stub
    	totalUsers++;
    	currentUsers++;
    	
    	ctx=event.getSession().getServletContext();
    	ctx.setAttribute("totalUsers",totalUsers);
    	ctx.setAttribute("currentUsers",currentUsers);
    }

	/**
     * @see HttpSessionListener#sessionDestroyed(HttpSessionEvent)
     */
    public void sessionDestroyed(HttpSessionEvent event)  { 
         // TODO Auto-generated method stub
    	currentUsers--;
    	ctx.setAttribute("currentUsers", currentUsers);
    }
	
}
