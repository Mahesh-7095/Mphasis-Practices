

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletOne
 */
//@WebServlet("/ServletOne")
public class ServletOne extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletOne() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pwriter = response.getWriter();
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		if(username.equals("admin") && password.equals("admin")) {
			RequestDispatcher dis=request.getRequestDispatcher("ServletTwo");
			dis.forward(request, response);
		} else {
			pwriter.print("<font color='red'><h3>User name or password is incorrect!</h3>");
			RequestDispatcher dis=request.getRequestDispatcher("login.html");
			dis.include(request, response);
		}
	}

}
