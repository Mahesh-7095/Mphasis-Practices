

import javax.servlet.ServletRequest;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class CustomerRequestListener
 *
 */
@WebListener
public class CustomerRequestListener implements ServletRequestListener {

    /**
     * Default constructor. 
     */
    public CustomerRequestListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletRequestListener#requestDestroyed(ServletRequestEvent)
     */
    public void requestDestroyed(ServletRequestEvent sre)  { 
         // TODO Auto-generated method stub
    	ServletRequest request = sre.getServletRequest();
    	System.out.println("Request has been served and ended");
    	
    }

	/**
     * @see ServletRequestListener#requestInitialized(ServletRequestEvent)
     */
    public void requestInitialized(ServletRequestEvent sre)  { 
         // TODO Auto-generated method stub
    	ServletRequest request = sre.getServletRequest();
    	System.out.println("A new request has Arrived");
    	System.out.println("Accessing request parameters using ServletRequest");
    	System.out.println("Welcome "+request.getParameter("username"));
    	System.out.println("How is weather in "+request.getParameter("cityname"));
    	System.out.println("Request Protocol: "+request.getProtocol());
    	System.out.println("Request Server Name: "+request.getServerName());
    }
	
}
